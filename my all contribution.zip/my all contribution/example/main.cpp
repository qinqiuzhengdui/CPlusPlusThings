#include <iostream>
//#include "toomanyclass.h" 
#include "ptr.h"
int main() {
    Device phone(1001);
    User u1(1, "Bob", phone);
    u1.display();  // ���: ID: 1, Name: Bob, Device ID: 1001, Scores: [0, 0, 0], Config: 100

    User u2(2, "Charlie");  // ʹ��ί�й��캯��
    u2.display();  // ���: ID: 2, Name: Charlie, Device ID: 0, Scores: [0, 0, 0], Config: 100

    return 0;
}
