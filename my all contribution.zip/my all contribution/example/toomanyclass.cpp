#include "toomanyclass.h"
#include <iostream>

void Person::display() const {
    std::cout << "ID: " << id 
              << ", Name: " << name 
              << ", City: " << address.getCity() 
              << ", Score: " << *scorePtr 
              << std::endl;
}
